<?php $__env->startSection('content'); ?>
Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illo enim non sequi adipisci aspernatur distinctio dignissimos quam dolore. Earum ipsa obcaecati, aliquam explicabo harum dolorem corrupti tenetur iste laboriosam illum!
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\drruna\resources\views/frontend/service.blade.php ENDPATH**/ ?>