<?php $__env->startSection('title'); ?>
    Home Page || Dr Runa Akter Dola
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('frontend.home.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.service', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.process', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.youtube', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.experience', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="container my-5">
        <div class="p-1 shadow-lg help-section-wrapper rounded-4" data-aos="zoom-in">
            <div
                class="p-4 help-banner-premium d-flex flex-column flex-md-row align-items-center justify-content-between p-md-5">
                <div class="mb-4 text-center content-side text-md-start mb-md-0">
                    <h2 class="mb-2 fw-bold">Do You Have Health Concerns?</h2>
                    <p class="mb-0 opacity-75">
                        Need Immediate Medical Attention? Get Expert Help From <strong>Dr. Runa Akter Dola</strong> —
                        <span class="text-success-light fw-semibold">Specialist in High-Risk Pregnancy & Feto-Maternal
                            Medicine.</span>
                    </p>
                </div>
                <div class="button-side">
                    <button class="btn-help-pulse">
                        <span>I NEED HELP</span>
                        <i class="fas fa-hand-holding-medical ms-2"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('frontend.home.review', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('frontend.home.educaton', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\drruna\resources\views/frontend/index.blade.php ENDPATH**/ ?>